using Test

using BenchmarkTools
using Statistics

using CuArrays
import CUDAdrv

function Btmult!(y,x)
    s=size(x)
    for i=1:s[1]-1
        yi=view(y,i,:,:)
        xi=view(x, i,:, :)
        xip1=view(x, i+1,:, :)
        yi.=xip1.-xi
        # y[i,:,:].=x[i+1,:,:].-x[i,:,:]
    end
end

function Btmult_plan!(y,x)
    s=size(x)
    for k=1:s[3]-1
        yk=view(y,:,:,k)
        xk=view(x, :, :, k)
        xkp1=view(x, :, :, k+1)
        yk.=xkp1.-xk
        # y[:,:,k].=x[:,:,k+1].-x[:,:,k]
    end
end

function Btmult_new!(y,x)
    yv = @view y[:,:,1:end-1]
    xv = @view x[:,:,1:end-1]
    xvp1 = @view x[:,:,2:end]
    @. yv = xvp1 - xv
end

function init3D(n::Int64)
    x = zeros(Float32, (n,n,n))
    copyto!(x,1:length(x))
    y = zeros(Float32, (n,n,n))
    x,y
end

function test_binaryf!(y, x, bf; nsample=100)
    for i in 1:nsample
        bf(y,x)
    end
    return
end

function benchmark(N=100)
    for bf in (Btmult!, Btmult_plan!, Btmult_new!)
        x,y = init3D(N)
        x_gpu, y_gpu = CuArray(x), CuArray(y)

        test_binaryf!(y, x, bf)
        test_binaryf!(y_gpu, x_gpu, bf)
        @test y ≈ Array(y_gpu)

        @show cpu = @benchmark begin
            test_binaryf!(x, y, $bf)
        end setup=((x,y) = init3D($N))

        @show gpu = @benchmark begin
            CuArrays.@sync test_binaryf!(x_gpu, y_gpu, $bf)
        end setup=((x,y) = init3D($N); (x_gpu, y_gpu) = (CuArray(x), CuArray(y)))

        @info "GPU vs CPU for $bf" judge(median(gpu),median(cpu))
    end
end